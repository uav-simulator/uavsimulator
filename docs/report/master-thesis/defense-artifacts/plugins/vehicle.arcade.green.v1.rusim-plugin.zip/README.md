# Arcade Free Racing Car (Green)

- **Plugin ID:** `vehicle.arcade.green.v1`
- **Type:** vehicle
- **Version:** 1.0.0

Ground robot profile with ARCADE Free Racing Car green visual body. User-installable demo plugin for live install showcase during master thesis defense.

## Installation

```bash
rusim plugin install vehicle.arcade.green.v1.rusim-plugin.zip
```
